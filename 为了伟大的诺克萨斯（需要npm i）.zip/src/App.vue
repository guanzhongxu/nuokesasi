<template>
  <div id="app">
    <!-- 头部header区域 -->
    <mt-header fixed title="为了伟大的诺克萨斯">
      <span  slot="left" @click="goback" v-show='flag'>
      <mt-button icon="back">返回</mt-button>
  </span>
    </mt-header>

    <!-- 中间内容区域 -->
    <transition>
      <router-view></router-view>
    </transition>

    <!-- 底部路由连接区域 -->
    <nav class="mui-bar mui-bar-tab">
      <router-link class="mui-tab-item-guan" to="/home">
        <span class="mui-icon mui-icon-home"></span>
        <span class="mui-tab-label">首页</span>
      </router-link>
      <router-link class="mui-tab-item-guan" to="/member">
        <span class="mui-icon mui-icon-contact"></span>
        <span class="mui-tab-label">会员</span>
      </router-link>
      <router-link class="mui-tab-item-guan" to="/shopingcar">
        <span class="mui-icon mui-icon-extra mui-icon-extra-cart">
          <span class="mui-badge">0</span>
        </span>
        <span class="mui-tab-label">购物车</span>
      </router-link>
      <router-link class="mui-tab-item-guan" to="/search">
        <span class="mui-icon mui-icon-search"></span>
        <span class="mui-tab-label">搜索</span>
      </router-link>
    </nav>
  </div>
</template>

<script>
export default {
  name: "App",
  data:function(){
    return {
      flag:false
    }
  },
  created(){
    //刷新页面后的返回摁钮显示状态判断
    this.flag = this.$route.path ==='/home'? false : true
  },
  methods:{
    goback(){
      //返回摁钮
      this.$router.go(-1);
    }
  },
  watch:{
    //监听$route.path 的变化，来确定返回摁钮的显示与隐藏
      "$route.path":function(){
        if(this.$route.path==='/home'){
          this.flag = false;
        }else{
          this.flag = true;
        }
      }
    }
};
</script>

<style scoped>
.header {
  position: relative;
}

#app {
  padding-top: 40px;
  overflow: hidden;
  padding-bottom: 50px;
}
.v-enter {
  transform: translateX(100%);
}

.v-leave-to {
  transform: translateX(-100%);
  position: absolute;
}
.v-enter-active,
.v-leave-active {
  transition: all 0.3s ease;
}
.mui-bar-tab .mui-tab-item-guan .mui-active {
  color: #007aff;
}
.mui-bar-tab .mui-tab-item-guan {
  display: table-cell;
  overflow: hidden;
  width: 1%;
  height: 50px;
  text-align: center;
  vertical-align: middle;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: #929292;
}
.mui-bar-tab .mui-tab-item-guan .mui-icon {
  top: 3px;
  width: 24px;
  height: 24px;
  padding-top: 0;
  padding-bottom: 0;
}
.mui-bar-tab .mui-tab-item-guan .mui-icon ~ .mui-tab-label {
  font-size: 11px;
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
}
.mint-header.is-fixed {
  z-index: 999;
}
</style>
