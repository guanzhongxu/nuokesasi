<template>
  <div>
    <mt-radio title="请选择支付方式"  v-model="value" :options="options"></mt-radio>
    <mt-radio title="请选择充值金额" v-model="number" :options="payNumber"></mt-radio>
    <p>您充值的数量是：</p>
    <input type="number" placeholder="其他数量" v-model="number">
    <mt-button size="large" type="primary" @click="recharge"> 确认充值</mt-button>
  </div>
</template>

<script>


export default {
  data: function() {
    return {
  
      options: [
        {
          label: "Q币支付",
          value: "Q币支付"
        },
        {
          label: "QQ钱包支付",
          value: "QQ钱包支付"
        },
        {
          label: "微信支付",
          value: "微信支付"
        }
      ],
      payNumber : [{label:"50元" ,value:"50"}, {label:"100元",value:"100"}, {label:"200元",value:"200"},{label:"其他数量",value:"0"}],
      value:'',
      number:null
    };
  },
  methods:{
      recharge(){
          //充值函数 发给后台 进行用户的充值
      }
  }
};
</script>
<style scoped>
input{
    border: 1px solid #22afff;
}
</style>
