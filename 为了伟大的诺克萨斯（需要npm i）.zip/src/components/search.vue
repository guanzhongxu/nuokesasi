<template>
    <div>
        <p>我还没有做搜索页面(＞人＜；)对不起</p>
        <img src="http://img3.imgtn.bdimg.com/it/u=2338457257,401560490&fm=26&gp=0.jpg" alt="">
    </div>
</template>
<script>
export default {
    
}
</script>

<style scoped>
p {
    font-size:16px;
    color: yellowgreen;
}
img{
    width: 100%;
}
</style>
