<template>
    <div>
        <h3>您有什么问题可以写在下面的输入框中，我们会尽快为您处理您反馈的问题，对您造成的不便，还请原谅</h3>
        <textarea placeholder="请您输入您要反馈的问题，最多1000个字符" maxlength="1000" v-model="value" ></textarea>
        <mt-button type="primary" size='large' @click='feedback'>确认提交</mt-button>
    </div>
</template>

<script>
export default {
    data:function(){
        return {
            value:''
        }
    },
    methods:{
        feedback(){
            //提交反馈 没有后台数据，先不moni
            // this.$http.post('url',this.value).then(function(reslut){
            //     this.$toast("发送成功")
            // })
             this.$toast("发送成功");
             this.value = '';
        }
    }
}
</script>

<style scoped>
h3{
    margin: 8px 0;
    font-size: 14px;
    color: #c3c3c3;
    font-weight: 400;
    text-indent: 2em;
}
textarea{
    font-size: 14px;
    padding: 0;
    text-indent:2em;
    height: 350px;
}
</style>
