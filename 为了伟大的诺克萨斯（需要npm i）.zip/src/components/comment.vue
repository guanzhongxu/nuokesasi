<template>
<!-- 这个页面是公用评论页面 -->
  <div class="comment">
    <h3>发表评论</h3>
    <hr>
    <textarea placeholder="请输入您要评论的内容(最多120个字符)" maxlength="120" v-model="content"></textarea>
    <mt-button type="primary" size="large" @click="add_comment">提交</mt-button>
    <ul>
      <li v-for="(item,index) in commentruiwen" :key="item.id">
        <div>
          <p class="title">
            <span>
              <span>第{{ index+1 }}楼</span>
              <span>用户:匿名用户</span>
            </span>
            <span>发表时间：{{ item.add_time | dateFormat}}</span>
          </p>
          <p class="content">{{item.content }}</p>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  data: function() {
    return {
      content: ""
    };
  },
  props: ["commentruiwen"],
  methods: {
    add_comment() {
      if (!this.content.length) {
        return this.$toast("请您输入评论内容");
      }
      let obj = {
        id: this.commentruiwen.length + 1,
        uesr: "匿名用户",
        add_time: new Date(),
        content: this.content
      };
      this.commentruiwen.unshift(obj);
      this.content = "";
    }
  }
};
</script>
<style scoped>
.comment ul {
  list-style: none;
  padding: 0;
  line-height: 30px;
}
.comment textarea {
  margin: 0;
}
.comment h3 {
  color: #3c3c3c;
}
.comment .title {
  background-color: #3c3c3c;
  display: flex;
  justify-content: space-between;
}
.comment .content {
  font-size: 16px;
  color: #000;
  text-indent: 2em;
  margin: 0;
}
</style>
