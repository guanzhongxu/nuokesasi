<template>
    <div class="ruiwen">
        <h2 class="title">瑞文CG觉醒</h2>
        <p class="subtitle">画作</p>
        <div class="info">
            <span>发布时间:2019年3月4日</span>
            <span>浏览数:96</span>
        </div>
        <div class="img">
            <img v-lazy="'https://shp.qpic.cn/cms_pic/1347048808/84a7804687377d6f6dc4f5166ba65f2f/0'" />
            <img v-lazy="'https://shp.qpic.cn/cms_pic/1356007806/b6d0f5cbf9fdbafc05ad19a6d97e9e0f/0'" />
        </div>
        <ruiwencomment :commentruiwen="this.commentruiwen"></ruiwencomment>
    </div>
</template>
<script>
import ruiwencomment from '../comment.vue';
export default {
   components:{
       ruiwencomment
   },
   data:function(){
       return {
           commentruiwen:[
           ]
       }
   },
    created() {
        let obj ={
            "uesr":"匿名用户",
                   "add_time": new Date(),
                   "content":"断剑重铸之日，骑士归来之时"
        };
        this.commentruiwen.unshift(obj);
    },
}
</script>
<style scoped>
.ruiwen{
    padding: 4px 4px 0px 4px;
}
.ruiwen .title{
    font-size:18px;
    font-weight: 600;
    text-align: center;
    color: #3c3c3c;
}
.ruiwen .subtitle{
    text-align: center;
    border-bottom: 2px solid #c3c3c3;
}
.ruiwen .info{
    font-size: 14px;
    display: flex;
    justify-content: space-between;
    color: #226faa;
}
.ruiwen .img img{
    width: 100%;
    height: 100%;
}
img[lazy=loading] {
  width: 40px;
  height: 300px;
  margin: auto;
}
</style>
