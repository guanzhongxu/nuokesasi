<template>
    <div class="nuoke">
        <h2 class="title">Prey in Claw</h2>
        <p class="subtitle">画作</p>
        <div class="info">
            <span>发布时间:2019年3月3日</span>
            <span>浏览数:206</span>
        </div>
        <div class="img">
            <img v-lazy="'https://shp.qpic.cn/cms_pic/1354003925/8b95a1ecc563941aa3fc3074abfa4301/0'" />
        </div>
        <ruiwencomment :commentruiwen="this.commentruiwen"></ruiwencomment>
    </div>
</template>
<script>
import ruiwencomment from '../comment.vue';
export default {
   components:{
       ruiwencomment
   },
   data:function(){
       return {
           commentruiwen:[
           ]
       }
   },
    created() {
        let obj ={
            id:1,
                    "uesr":"匿名用户",
                   "add_time": new Date(),
                   "content":"藐视诺克萨斯的崛起，你将死无葬身之地"
        };
        this.commentruiwen.unshift(obj);
    },
}
</script>
<style scoped>
.nuoke{
    padding: 4px 4px 0px 4px;
}
.nuoke .title{
    font-size:18px;
    font-weight: 600;
    text-align: center;
    color: #3c3c3c;
}
.nuoke .subtitle{
    text-align: center;
    border-bottom: 2px solid #c3c3c3;
}
.nuoke .info{
    font-size: 14px;
    display: flex;
    justify-content: space-between;
    color: #226faa;
}
.nuoke .img img{
    width: 100%;
    height: 100%;
}
img[lazy=loading] {
  width: 40px;
  height: 300px;
  margin: auto;
}
</style>
