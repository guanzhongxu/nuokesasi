<template>
  <div>
    <ul class="mui-table-view">
      <li class="mui-table-view-cell mui-media" v-for="item in lolImg" :key="item.id">
        <router-link :to="'/home/news/newsinfo/'+item.id">
          <img class="mui-media-object mui-pull-left" v-lazy="item.url">
          <div class="mui-media-body">
            {{ item.title }}
            <p class="mui-ellipsis">
              <span>{{ item.content }}</span>
              <span>{{ item.add_time}}</span>
            </p>
          </div>
        </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
let lolImg = [
  {
    id: 1,
    title: "觉醒CG瑞文",
    url:
      "http://shp.qpic.cn/cms_pic/1351007917/62d7d21788840ed502bfeafcade5e33c/258",
    content: "你今天画画了吗",
    add_time: "2019.3.5 12:30:09"
  },
  {
    id: 2,
    title: "Prey in Claw",
    url:
      "http://shp.qpic.cn/cms_pic/1365043872/f3dd3a7bdd79f78f8251f9342ba68fb0/258",
    content: "美服fanart精选",
    add_time: "2019.3.5 12:30:09"
  },
  {
    id: 3,
    title: "幽魂之刺：泰隆",
    url:
      "http://shp.qpic.cn/cms_pic/1288002225/df79b1b4139746071d145fe01518faf0/258",
    content: "HANEJIRO",
    add_time: "2019.3.5 12:30:09"
  },
  {
    id: 4,
    title: "KDA卡特琳娜",
    url:
      "http://shp.qpic.cn/cms_pic/1235009600/3c8bd42efcc5376acdc20733e2c46bf4/258",
    content: "过后公布",
    add_time: "2019.3.5 12:30:09"
  }
];
export default {
  data: function() {
    return {
      lolImg: lolImg
    };
  }
};
</script>
<style scoped>
.mui-media-body {
  font-size: 13px;
}
.mui-ellipsis {
  font-size: 12px;
  color: #226aff;
  display: flex;
  justify-content: space-between;
}
img[lazy=loading] {
  width: 40px;
  height: 300px;
  margin: auto;
}
</style>
