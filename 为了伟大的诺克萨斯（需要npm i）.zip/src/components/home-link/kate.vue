<template>
  <div class="kate">
    <h2 class="title">KDA卡特琳娜</h2>
    <p class="subtitle">画作</p>
    <div class="info">
      <span>发布时间:2019-01-26</span>
      <span>浏览数: 298</span>
    </div>
    <div class="img">
      <img v-lazy="'https://shp.qpic.cn/cms_pic/1333033021/7e2a3adbe8f97d9da77beb4af425c7cb/0'">
      <img v-lazy="'https://shp.qpic.cn/cms_pic/1242038444/7622bc82defeaff4b6763e4bef048ed6/0'">
      <vue-preview :slides="slide1" @close="handleClose"></vue-preview>
    </div>
    <ruiwencomment :commentruiwen="this.commentruiwen"></ruiwencomment>
  </div>
</template>
<script>
import ruiwencomment from "../comment.vue";
export default {
  components: {
    ruiwencomment
  },
  data: function() {
    return {
      commentruiwen: [],
      slide1: [
          {
            src: 'https://shp.qpic.cn/cms_pic/1333033021/7e2a3adbe8f97d9da77beb4af425c7cb/0',
            msrc: 'https://shp.qpic.cn/cms_pic/1333033021/7e2a3adbe8f97d9da77beb4af425c7cb/0',
            alt: '卡特琳娜',
            title: '卡特琳娜',
            w: 600,
            h: 400
          }
        ]
      
    };
  },
  methods: {
      handleClose () {
        //console.log('close event')
        return false;
      }
  },
  created() {
    let obj = {
      id: 1,
      uesr: "匿名用户",
      add_time: new Date(),
      content: "以敌人之血，祭我大诺克萨斯~"
    };
    this.commentruiwen.unshift(obj);
  }
};
</script>
<style scoped>
.kate {
  padding: 4px 4px 0px 4px;
}
.kate .title {
  font-size: 18px;
  font-weight: 600;
  text-align: center;
  color: #3c3c3c;
}
.kate .subtitle {
  text-align: center;
  border-bottom: 2px solid #c3c3c3;
}
.kate .info {
  font-size: 14px;
  display: flex;
  justify-content: space-between;
  color: #226faa;
}
.kate .img img {
  width: 100%;
  height: 100%;
}
img[lazy=loading] {
  width: 40px;
  height: 300px;
  margin: auto;
}
</style>
