<template>
  <div class="qinnv">
    <h2 class="title">吃汤圆！！</h2>
    <p class="subtitle">画作</p>
    <div class="info">
      <span>发布时间:2019-02-15 22:09:42</span>
      <span>浏览数:  1828</span>
    </div>
    <div class="img">
      <img v-lazy="'https://shp.qpic.cn/cms_pic/1190200072/60441fd4d3851047b97905ae61c7c0d3/0'">
    </div>
    <ruiwencomment :commentruiwen="this.commentruiwen"></ruiwencomment>
  </div>
</template>
<script>
import ruiwencomment from "../comment.vue";
export default {
  components: {
    ruiwencomment
  },
  data: function() {
    return {
      commentruiwen: []
    };
  },
  created() {
    let obj = {
      id: 1,
      uesr: "匿名用户",
      add_time: new Date(),
      content: "要和谐~"
    };
    this.commentruiwen.unshift(obj);
  }
};
</script>
<style scoped>
.qinnv {
  padding: 4px 4px 0px 4px;
}
.qinnv .title {
  font-size: 18px;
  font-weight: 600;
  text-align: center;
  color: #3c3c3c;
}
.qinnv .subtitle {
  text-align: center;
  border-bottom: 2px solid #c3c3c3;
}
.qinnv .info {
  font-size: 14px;
  display: flex;
  justify-content: space-between;
  color: #226faa;
}
.qinnv .img img {
  width: 100%;
  height: 100%;
}
img[lazy=loading] {
  width: 40px;
  height: 300px;
  margin: auto;
}
</style>
