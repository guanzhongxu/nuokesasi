<template>
  <div class="nv">
    <h2 class="title">Firecracker Vayne Prestige Edition - Fanart</h2>
    <p class="subtitle">画作</p>
    <div class="info">
      <span>发布时间:2019-02-20 17:07:49    </span>
      <span>浏览数: 3662</span>
    </div>
    <div class="img">
      <img v-lazy="'https://shp.qpic.cn/cms_pic/1100104151/90fb419030ed07a2f3694d8531e65ae6/0'">
    </div>
    <ruiwencomment :commentruiwen="this.commentruiwen"></ruiwencomment>
  </div>
</template>
<script>
import ruiwencomment from "../comment.vue";
export default {
  components: {
    ruiwencomment
  },
  data: function() {
    return {
      commentruiwen: []
    };
  },
  created() {
    let obj = {
      id: 1,
      uesr: "匿名用户",
      add_time: new Date(),
      content: "肮脏的蠢蛋!"
    };
    this.commentruiwen.unshift(obj);
  }
};
</script>
<style scoped>
.nv {
  padding: 4px 4px 0px 4px;
}
.nv .title {
  font-size: 18px;
  font-weight: 600;
  text-align: center;
  color: #3c3c3c;
}
.nv .subtitle {
  text-align: center;
  border-bottom: 2px solid #c3c3c3;
}
.nv .info {
  font-size: 14px;
  display: flex;
  justify-content: space-between;
  color: #226faa;
}
.nv .img img {
  width: 100%;
  height: 100%;
}
img[lazy=loading] {
  width: 40px;
  height: 300px;
  margin: auto;
}
</style>
