<template>
  <div class="kaiyin">
    <h2 class="title">Death Sworn Rakan</h2>
    <p class="subtitle">画作</p>
    <div class="info">
      <span>2019-02-19 17:38:51</span>
      <span>浏览数: 1540</span>
    </div>
    <div class="img">
      <img v-lazy="'https://shp.qpic.cn/cms_pic/1160318136/4f5ad5090678a67afb7084787927eb11/258'">
    </div>
    <ruiwencomment :commentruiwen="this.commentruiwen"></ruiwencomment>
  </div>
</template>
<script>
import ruiwencomment from "../comment.vue";
export default {
  components: {
    ruiwencomment
  },
  data: function() {
    return {
      commentruiwen: []
    };
  },
  created() {
    let obj = {
      id: 1,
      uesr: "匿名用户",
      add_time: new Date(),
      content: "你把我教的太好了，劫"
    };
    this.commentruiwen.unshift(obj);
  }
};
</script>
<style scoped>
.kaiyin {
  padding: 4px 4px 0px 4px;
}
.kaiyin .title {
  font-size: 18px;
  font-weight: 600;
  text-align: center;
  color: #3c3c3c;
}
.kaiyin .subtitle {
  text-align: center;
  border-bottom: 2px solid #c3c3c3;
}
.kaiyin .info {
  font-size: 14px;
  display: flex;
  justify-content: space-between;
  color: #226faa;
}
.kaiyin .img img {
  width: 100%;
  height: 100%;

}
img[lazy=loading] {
  width: 40px;
  height: 300px;
  margin: auto;
}
</style>
