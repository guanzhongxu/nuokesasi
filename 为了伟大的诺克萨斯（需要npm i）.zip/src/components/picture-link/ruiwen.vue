<template>
  <div class="ruiwen">
    <h2 class="title">新春瑞文“火舞银花”</h2>
    <p class="subtitle">画作</p>
    <div class="info">
      <span>发布时间:2019-01-28 15:28:50</span>
      <span>浏览数: 3367</span>
    </div>
    <div class="img">
      <img v-lazy="'https://shp.qpic.cn/cms_pic/1336014728/acc4b1e07a5fd3d5decef58a83ee9794/0'">
      <img v-lazy="'https://shp.qpic.cn/cms_pic/1295009763/51e3790d5eb0efda77099b7032fa61d3/0'">
    </div>
    <ruiwencomment :commentruiwen="this.commentruiwen"></ruiwencomment>
  </div>
</template>
<script>
import ruiwencomment from "../comment.vue";
export default {
  components: {
    ruiwencomment
  },
  data: function() {
    return {
      commentruiwen: []
    };
  },
  created() {
    let obj = {
      id: 1,
      uesr: "匿名用户",
      add_time: new Date(),
      content: "我已经流浪了如此之久!"
    };
    this.commentruiwen.unshift(obj);
  }
};
</script>
<style scoped>
.ruiwen {
  padding: 4px 4px 0px 4px;
}
.ruiwen .title {
  font-size: 18px;
  font-weight: 600;
  text-align: center;
  color: #3c3c3c;
}
.ruiwen .subtitle {
  text-align: center;
  border-bottom: 2px solid #c3c3c3;
}
.ruiwen .info {
  font-size: 14px;
  display: flex;
  justify-content: space-between;
  color: #226faa;
}
.ruiwen .img img {
  width: 100%;
  height: 100%;
}
img[lazy=loading] {
  width: 40px;
  height: 300px;
  margin: auto;
}
</style>
