<template>
  <div>
    <div id="slider" class="mui-slider ">
				<div id="sliderSegmentedControl" class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
					<div class="mui-scroll">
						<a class="mui-control-item mui-active" href="#item1mobile" data-wid="tab-top-subpage-1.html">
							诺克萨斯
						</a>
						<a class="mui-control-item" href="#item2mobile" data-wid="tab-top-subpage-2.html">
							德玛西亚
						</a>
						<a class="mui-control-item" href="#item3mobile" data-wid="tab-top-subpage-3.html">
							班德尔城
						</a>
						<a class="mui-control-item" href="#item4mobile" data-wid="tab-top-subpage-4.html">
							战争学院
						</a>
						<a class="mui-control-item" href="#item5mobile" data-wid="tab-top-subpage-5.html">
							艾欧尼亚
						</a>
        
					</div>
				</div>

			</div>
    <ul class="mui-table-view">
      <li class="mui-table-view-cell mui-media" v-for="item in lolImg" :key="item.id">
        <router-link :to="'/home/picture/pictureinfo/'+item.id">
          <img class="mui-media-object mui-pull-left" v-lazy="item.url">
          <div class="mui-media-body">
            {{ item.title }}
            <p class="mui-ellipsis">
              <span>{{ item.content }}</span>
              <span>{{ item.add_time}}</span>
            </p>
          </div>
        </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
import mui from '../../mui/dist/js/mui.js';
let lolImg = [
  {
    id: 1,
    title: "新春瑞文“火舞银花”",
    url:
      "https://shp.qpic.cn/cms_pic/1336014728/acc4b1e07a5fd3d5decef58a83ee9794/0",
    content: "鱼兮兮",
    add_time: "2019-01-28 15:28:50"
  },
  {
    id: 2,
    title: "吃汤圆！！",
    url:
      "https://shp.qpic.cn/cms_pic/1190200072/60441fd4d3851047b97905ae61c7c0d3/0",
    content: "时代的眼泪烤考拉",
    add_time: "2019-02-15 22:09:42"
  },
  {
    id: 3,
    title: "Firecracker Vayne Prestige Edition - Fanart",
    url:
      "https://shp.qpic.cn/cms_pic/1100104151/90fb419030ed07a2f3694d8531e65ae6/0",
    content: "美服Fanart精选",
    add_time: "2019-02-20 17:07:49"
  },
  {
    id: 4,
    title: "Death Sworn Rakan",
    url:
      "https://shp.qpic.cn/cms_pic/1160318136/4f5ad5090678a67afb7084787927eb11/0",
    content: "美服Fanart精选",
    add_time: "2019-02-19 17:38:51"
  }
];
export default {
  data: function() {
    return {
      lolImg: lolImg
    };
  },
  mounted(){
    mui('.mui-scroll-wrapper').scroll({
  	deceleration: 0.0005 //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
    });
  }
};
</script>
<style scoped>
.mui-media-body {
  font-size: 13px;
}
.mui-ellipsis {
  font-size: 12px;
  color: #226aff;
  display: flex;
  justify-content: space-between;
}
* {
  touch-action: pan-y;
}
img[lazy=loading] {
  width: 40px;
  height: 300px;
  margin: auto;
}

</style>
