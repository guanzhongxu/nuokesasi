<template>
    <div>
        <p>我还没有做会员页面，先拿个图来应付一下(#^.^#)</p>
        <img src="http://img0.imgtn.bdimg.com/it/u=286922766,618831174&fm=26&gp=0.jpg" alt="">
    </div>
</template>
<script>
export default {
    
}
</script>

<style scoped>
p {
    font-size:16px;
    color: yellowgreen;
}
img{
    width: 100%;
}
</style>