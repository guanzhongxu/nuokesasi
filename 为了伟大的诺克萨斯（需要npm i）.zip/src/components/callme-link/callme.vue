<template>
  <div class="callme">
      <form action="#">
          <div>
              <label>&nbsp;&nbsp;姓名:</label>
              <input type="text" placeholder="请输入您的姓名" v-model="username">
          </div>
          <div>
              <label>&nbsp;&nbsp;邮箱:</label>
              <input type="email" placeholder="请输入您的邮箱" v-model="email">
          </div>
          <div>
              <label>&nbsp;&nbsp;手机号:</label>
              <input type="tel" placeholder="请输入您的手机号" v-model="phone">
          </div>
        
          <div>
              <label>&nbsp;&nbsp;自我介绍:</label>
              <textarea v-model="introduction"></textarea>
          </div>
          <div>
              <mt-button type="primary" size="large">发送信息</mt-button>
          </div>
      </form>
  </div>
</template>

<script>
export default {
    data(){
        return {
            username:'',
            email:'',
            phone:'',
            introduction:''
        }
    }
};
</script>

<style scoped>
label{
    font-size:15px;
    color:cornflowerblue;
}
input,textarea {
    font-size: 14px;
    color: #c3c3c3;
}

</style>
