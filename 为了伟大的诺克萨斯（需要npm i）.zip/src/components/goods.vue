<template>
    <div>
        <ul class="mui-table-view mui-table-view-chevron">
				<li class="mui-table-view-cell mui-media">
					<router-link class="mui-navigate-right" to="goods/goodslist">
						<img class="mui-media-object mui-pull-left" src="https://midas.gtimg.cn/midas/images/logo/lol/90.png">
						<div class="mui-media-body">
							点券充值
							<p class='mui-ellipsis'>Q币支付,QQ钱包支付,微信支付.</p>
						</div>
					</router-link>
				</li>
			</ul>
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>

</style>
