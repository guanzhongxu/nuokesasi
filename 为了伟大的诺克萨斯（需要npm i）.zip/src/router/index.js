import Vue from 'vue'
import Router from 'vue-router'
//主页面
import home from '../components/home.vue';
//会员页面
import member from '../components/member.vue';
//购物车页面
import shopingcar from '../components/shopingcar.vue';
//搜索页面
import search from '../components/search.vue';
/*以上是4个主页面（下方导航栏的4个选项页面）*/ 
//新闻资讯页面
import news from '../components/home-link/news.vue';
//新闻资讯里的小页面
import ruiwen from '../components/home-link/ruiwen.vue';
import tailong from '../components/home-link/tailong.vue';
import nuoke from '../components/home-link/nuoke.vue';
import kate from '../components/home-link/kate.vue';
/*以上4个为新闻资讯里的小页面 */
//图片分享页面
import picture from '../components/picture-link/picture.vue';
//图片分享小页面
import pruiwen from '../components/picture-link/ruiwen.vue';
import qinnv from '../components/picture-link/qinnv.vue';
import vn from '../components/picture-link/vn.vue';
import kaiyin from '../components/picture-link/kaiyin.vue';
/*以上是4个图片分享里的小页面 */

//商品购买页面
import goods from '../components/goods.vue';
import goodslist from '../components/goods-link/goodslist.vue';

//留言反馈
import feedback from '../components/feedback.vue';

//视频分享
import video from '../components/video-link/videolist.vue';

//练习我们
import callme from '../components/callme-link/callme.vue';
Vue.use(Router);
export default new Router({
  routes: [
    { path: '/', redirect: "home" },
    { path: '/home', component: home },
    { path: '/member', component: member },
    { path: '/shopingcar', component: shopingcar },
    { path: '/search', component: search },
    { path: '/home/news', component: news },
    { path: '/home/news/newsinfo/1', component: ruiwen },
    { path: '/home/news/newsinfo/2', component: nuoke },
    { path: '/home/news/newsinfo/3', component: tailong },
    { path: '/home/news/newsinfo/4', component: kate },
    { path: '/picture', component: picture },
    { path: '/home/picture/pictureinfo/1', component: pruiwen },
    { path: '/home/picture/pictureinfo/2', component: qinnv },
    { path: '/home/picture/pictureinfo/3', component: vn },
    { path: '/home/picture/pictureinfo/4', component: kaiyin },
    { path: '/goods', component: goods },
    { path: '/goods/goodslist', component: goodslist },
    { path: '/home/feedback', component: feedback },
    { path: '/home/video', component: video },
    { path: '/home/callme', component: callme}
  ],
  linkActiveClass: 'mui-active'
})
