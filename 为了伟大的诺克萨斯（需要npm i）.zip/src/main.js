// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import App from './App';
import router from './router';
import VueResource from 'vue-resource'
Vue.use(VueResource);
//导入时间插件
import moment from 'moment';
//导入mint-ui
import Mint from 'mint-ui';
Vue.use(Mint);
import 'mint-ui/lib/style.css'
Vue.config.productionTip = false;
//导入mui样式
import './mui/dist/css/mui.css';
import './mui/dist/css/icons-extra.css';
//配置post请求
Vue.http.options.emulateJSON = true;
Vue.http.options.emulateHTTP = true;
//导入缩略图
import VuePreview from 'vue-preview';
Vue.use(VuePreview);
//定义全局时间过滤器
Vue.filter('dateFormat',function(datastr,pattern='YYYY-MM-DD HH:mm:ss'){
 return  moment(datastr).format(pattern)
});
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  render:c=>c(App)

})
